# -*- coding: utf-8 -*-
"""
Created on Tue Apr  6 14:46:57 2021

@author: mathiew
"""

"""Méthode de dichotomie"""

import math
from math import*
def dichotomie (f, a0, b0, epsilon, Nitermax):
    n=0
    d=b0
    g=a0
    while abs(d - g) > epsilon and n<Nitermax:
        m = ( g + d )/2
        n+=1
        if f ( m ) == 0:
            return m
        elif f ( g ) * f ( m ) <= 0:
            d = m
        else :
            g = m
    return ("m=",m,"n=",n)


import math 
"""Fonction 1:"""
def f(x):
    return x**4+3*x-9

print(dichotomie(f, 1, 2, 1E-6, 5E4))
print(dichotomie(f, -2, -1,1E-10, 1E4))

"""Fonction 2:"""
def f2(x):
    return 3*cos(x) - x - 2

print(dichotomie(f2, -2, -1, 1E-10, 1E4))
print(dichotomie(f2, 0, 1, 1E-10, 1E4))

"""Focntion 3:"""
def f3(x):
    return x*exp(x) - 7
print(dichotomie(f3, 1, 2, 1E-10, 1E4))



 



               