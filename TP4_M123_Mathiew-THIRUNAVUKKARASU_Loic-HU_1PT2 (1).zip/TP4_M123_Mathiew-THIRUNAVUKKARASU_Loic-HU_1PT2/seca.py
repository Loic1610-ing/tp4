# -*- coding: utf-8 -*-
"""
Created on Mon Apr 26 08:50:43 2021

@author: mathi
"""

"""Fonction sécante"""
from math import *
import numpy 
def  Secante(f,x0,x1,epsilon,Nitermax):
  n=0
  while abs(x1-x0)> epsilon and n < Nitermax:
      n= n+1
      x2 = x0 - f(x0)*(x1-x0)/(f(x1)-f(x0))
      x0= x1
      x1= x2
  return("x2=", x2,"n=", n)   

"""Fonction 1:"""
def f(x):
    return x**4+3*x-9

print(Secante(f, 1, 2, 1E-6, 5E4)) 
print(Secante(f, -2, -1,1E-10, 1E4))

"""Fonction 2:"""
def f2(x):
    return 3*cos(x) - x - 2

print(Secante(f2, -2, -1, 1E-10, 1E4))
print(Secante(f2, 0, 1, 1E-10, 1E4))

"""Focntion 3:"""
def f3(x):
    return x*exp(x) - 7
print(Secante(f3, 1, 2, 1E-10, 1E4))   

